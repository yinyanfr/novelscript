# NovelScript API References

//TODO