/**
 * Created by Ian on 2016/2/6.
 */
var NovelScript = {};
var ns = NovelScript;
ns.novelScript = "hina";
ns.version = 0.1;
// all
ns.effect = {};
ns.dev = {};

// constomization
ns.controls = {};
ns.default = {};

// init
ns.data = {};
ns.$frame = $("body");